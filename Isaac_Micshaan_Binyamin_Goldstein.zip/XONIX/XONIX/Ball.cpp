#include "Ball.h"



//Ball::Ball()
//{
//}


Ball::~Ball()
{
}
