#pragma once
#include "DynamicObject.h"

class Ball : public DynamicObject
{
public:
	using DynamicObject::DynamicObject;
	~Ball();
};

