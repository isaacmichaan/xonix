#include "Controller.h"
#include <iostream>

int main()
{
	Controller c;
	c.run();
}