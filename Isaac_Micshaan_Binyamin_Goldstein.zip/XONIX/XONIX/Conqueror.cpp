#include "Conqueror.h"



//Conqueror::Conqueror()
//{
//}


Conqueror::~Conqueror()
{
}
