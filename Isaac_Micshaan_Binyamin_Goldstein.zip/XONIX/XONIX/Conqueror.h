#pragma once
#include "DynamicObject.h"

class Conqueror : public DynamicObject
{
public:
	using DynamicObject::DynamicObject;
	~Conqueror();
};

