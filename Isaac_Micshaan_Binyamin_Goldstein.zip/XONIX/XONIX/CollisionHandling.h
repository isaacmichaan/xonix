#pragma once
#include "GameObject.h"

#include <iostream>
#include <typeinfo>

void processCollision(GameObject&, GameObject&);

