#include "StaticObject.h"



//StaticObject::StaticObject()
//{
//}


StaticObject::~StaticObject()
{
}
